import { useState, useEffect, useRef } from 'react'

const questionBank = {
  dotnet: {
    technical: [
      {
        q: 'What is the difference between ASP.NET MVC and ASP.NET Web API?',
        keywords: ['mvc', 'web api', 'view', 'http', 'rest', 'controller', 'response', 'json'],
        ideal: 'MVC returns Views (HTML), Web API returns data (JSON/XML). MVC is for web apps, Web API is for RESTful services.'
      },
      {
        q: 'Explain dependency injection in .NET Core with an example.',
        keywords: ['dependency', 'injection', 'interface', 'constructor', 'ioc', 'container', 'service', 'singleton', 'transient'],
        ideal: 'DI is a design pattern where dependencies are injected via constructor. .NET Core has built-in IoC container. Services registered as Singleton, Scoped, or Transient.'
      },
      {
        q: 'What is Entity Framework? Explain Code First vs Database First.',
        keywords: ['orm', 'code first', 'database first', 'migration', 'dbcontext', 'entity', 'model', 'schema'],
        ideal: 'EF is an ORM. Code First: write C# classes, EF creates DB. Database First: DB exists, EF generates classes.'
      },
      {
        q: 'What are the SOLID principles? Give a real example.',
        keywords: ['single responsibility', 'open closed', 'liskov', 'interface segregation', 'dependency inversion', 'solid'],
        ideal: 'S-Single Responsibility, O-Open/Closed, L-Liskov Substitution, I-Interface Segregation, D-Dependency Inversion'
      },
      {
        q: 'What is the difference between IEnumerable and IQueryable?',
        keywords: ['ienumerable', 'iqueryable', 'memory', 'database', 'linq', 'deferred', 'execution', 'sql'],
        ideal: 'IEnumerable executes in memory (client-side). IQueryable executes on database (server-side). IQueryable is better for large data.'
      },
      {
        q: 'Explain async/await in C#. When should you use it?',
        keywords: ['async', 'await', 'task', 'thread', 'asynchronous', 'non-blocking', 'io', 'performance'],
        ideal: 'async/await enables non-blocking code. Use for I/O operations like DB calls, API calls. Returns Task or Task<T>.'
      },
      {
        q: 'What is middleware in ASP.NET Core?',
        keywords: ['middleware', 'pipeline', 'request', 'response', 'use', 'run', 'next', 'configure'],
        ideal: 'Middleware is software in the HTTP pipeline that handles requests/responses. Each middleware calls next() to pass to next middleware.'
      },
      {
        q: 'What is the difference between abstract class and interface in C#?',
        keywords: ['abstract', 'interface', 'inherit', 'implement', 'multiple', 'method', 'constructor', 'access'],
        ideal: 'Abstract class can have implementation, Interface cannot (before C#8). Class can implement multiple interfaces but inherit one abstract class.'
      },
      {
        q: 'Explain the Repository Pattern with an example.',
        keywords: ['repository', 'pattern', 'data access', 'interface', 'abstraction', 'unit of work', 'crud'],
        ideal: 'Repository Pattern abstracts data access logic. IRepository interface with methods like GetAll, GetById, Add, Update, Delete.'
      },
      {
        q: 'What is LINQ? Give 3 examples of LINQ queries.',
        keywords: ['linq', 'query', 'where', 'select', 'orderby', 'groupby', 'join', 'lambda'],
        ideal: 'LINQ = Language Integrated Query. Examples: Where(), Select(), OrderBy(), GroupBy(), Join(), FirstOrDefault().'
      },
    ],
    hr: [
      { q: 'Tell me about yourself.', keywords: ['experience', 'skills', 'background', 'project', 'passionate', 'fresher', 'graduate'], ideal: 'Mention education, skills, projects, why you chose this field.' },
      { q: 'Why do you want to join our company?', keywords: ['company', 'growth', 'culture', 'technology', 'opportunity', 'learn', 'contribute'], ideal: 'Research the company. Mention specific things you like about them.' },
      { q: 'What are your strengths and weaknesses?', keywords: ['strength', 'weakness', 'improve', 'working on', 'skill', 'problem solving'], ideal: 'Genuine strength with example. Weakness + how you are improving it.' },
      { q: 'Where do you see yourself in 5 years?', keywords: ['grow', 'lead', 'senior', 'skill', 'contribute', 'goal', 'career'], ideal: 'Show ambition + loyalty. Mention growing within the company.' },
      { q: 'Why are you looking for a job change?', keywords: ['growth', 'opportunity', 'learn', 'challenge', 'skills', 'career'], ideal: 'Focus on growth, not negative reasons about current/previous company.' },
      { q: 'How do you handle pressure and tight deadlines?', keywords: ['prioritize', 'deadline', 'calm', 'plan', 'organize', 'communicate', 'deliver'], ideal: 'Mention prioritization, communication, staying calm, giving example.' },
      { q: 'Tell me about a challenging situation and how you handled it.', keywords: ['challenge', 'problem', 'solution', 'team', 'learned', 'result', 'handled'], ideal: 'Use STAR method: Situation, Task, Action, Result.' },
      { q: 'What motivates you at work?', keywords: ['learn', 'challenge', 'impact', 'team', 'solve', 'grow', 'achieve'], ideal: 'Mention learning, problem-solving, making impact, team collaboration.' },
      { q: 'Are you comfortable working in a team?', keywords: ['team', 'collaborate', 'communication', 'contribute', 'listen', 'support'], ideal: 'Yes + give example of successful team project.' },
      { q: 'Do you have any questions for us?', keywords: ['team', 'role', 'growth', 'culture', 'technology', 'expect', 'project'], ideal: 'Always ask questions! About team, tech stack, growth opportunities.' },
    ],
  },
  frontend: {
    technical: [
      { q: 'What is the difference between let, var, and const in JavaScript?', keywords: ['scope', 'block', 'function', 'hoisting', 'reassign', 'const', 'let', 'var'], ideal: 'var: function scope, hoisted. let: block scope, not hoisted. const: block scope, cannot reassign.' },
      { q: 'Explain the Virtual DOM in React.', keywords: ['virtual dom', 'real dom', 'reconciliation', 'diffing', 'performance', 'update', 'react'], ideal: 'Virtual DOM is a lightweight copy of real DOM. React compares (diffs) and updates only changed parts.' },
      { q: 'What are React hooks? Explain useState and useEffect.', keywords: ['hooks', 'usestate', 'useeffect', 'functional', 'state', 'side effect', 'lifecycle'], ideal: 'Hooks let functional components use state. useState manages state, useEffect handles side effects.' },
      { q: 'What is CSS Flexbox vs Grid? When to use which?', keywords: ['flexbox', 'grid', 'one dimension', 'two dimension', 'row', 'column', 'layout'], ideal: 'Flexbox: 1D layout (row OR column). Grid: 2D layout (rows AND columns). Grid for page layout, Flexbox for components.' },
      { q: 'What is event bubbling and event delegation in JavaScript?', keywords: ['bubbling', 'delegation', 'parent', 'child', 'propagation', 'event', 'listener'], ideal: 'Bubbling: event goes from child to parent. Delegation: attach one listener to parent for all children.' },
      { q: 'Explain closure in JavaScript with an example.', keywords: ['closure', 'scope', 'inner function', 'outer', 'access', 'variable', 'lexical'], ideal: 'Closure: inner function remembers variables from outer function even after outer returns.' },
      { q: 'What is the difference between == and === in JavaScript?', keywords: ['strict', 'loose', 'type', 'coercion', 'equality', 'convert'], ideal: '== loose equality (type coercion). === strict equality (no coercion). Always use ===.' },
      { q: 'What is a Promise in JavaScript?', keywords: ['promise', 'async', 'then', 'catch', 'resolve', 'reject', 'pending', 'fulfilled'], ideal: 'Promise handles async operations. States: pending, fulfilled, rejected. .then() for success, .catch() for error.' },
      { q: 'What is responsive design? How do you implement it?', keywords: ['responsive', 'media query', 'mobile', 'breakpoint', 'flexible', 'viewport', 'fluid'], ideal: 'Design that adapts to screen sizes. Use media queries, flexible units (%, rem), viewport meta tag.' },
      { q: 'Explain the React component lifecycle.', keywords: ['mount', 'update', 'unmount', 'useeffect', 'render', 'lifecycle', 'component'], ideal: 'Mount → Render → Update → Unmount. useEffect handles lifecycle in functional components.' },
    ],
    hr: [
      { q: 'Tell me about yourself.', keywords: ['skills', 'project', 'passionate', 'frontend', 'react', 'javascript', 'fresher'], ideal: 'Mention education, frontend skills, projects built.' },
      { q: 'Why frontend development?', keywords: ['visual', 'user', 'design', 'interface', 'creative', 'impact', 'experience'], ideal: 'Passion for building user interfaces, visual impact, user experience.' },
      { q: 'What are your strengths and weaknesses?', keywords: ['strength', 'weakness', 'improve', 'working', 'skill'], ideal: 'Genuine answer with examples.' },
      { q: 'Describe a project you are most proud of.', keywords: ['project', 'built', 'challenge', 'learned', 'impact', 'feature', 'technology'], ideal: 'Explain what you built, challenges faced, what you learned.' },
      { q: 'How do you stay updated with new technologies?', keywords: ['blog', 'youtube', 'documentation', 'learn', 'practice', 'community', 'course'], ideal: 'Mention specific sources: MDN, dev.to, YouTube channels, building projects.' },
      { q: 'How do you handle feedback on your code?', keywords: ['feedback', 'improve', 'learn', 'review', 'open', 'accept', 'better'], ideal: 'Welcome feedback, see it as learning opportunity, implement suggestions.' },
      { q: 'Tell me about a time you solved a difficult bug.', keywords: ['bug', 'debug', 'console', 'solve', 'found', 'fixed', 'tool'], ideal: 'Describe the bug, debugging approach, tools used, solution found.' },
      { q: 'How do you prioritize tasks?', keywords: ['priority', 'deadline', 'important', 'plan', 'organize', 'urgent', 'first'], ideal: 'Mention urgency vs importance, communication with team, planning.' },
      { q: 'Are you comfortable with Agile/Scrum?', keywords: ['agile', 'scrum', 'sprint', 'standup', 'team', 'iteration', 'backlog'], ideal: 'Yes + explain basic understanding of sprints, standups, retrospectives.' },
      { q: 'Do you have any questions for us?', keywords: ['team', 'technology', 'project', 'growth', 'culture', 'expect'], ideal: 'Ask about tech stack, team size, growth opportunities.' },
    ],
  },
  fullstack: {
    technical: [
      { q: 'What is the difference between REST API and GraphQL?', keywords: ['rest', 'graphql', 'endpoint', 'query', 'overfetch', 'underfetch', 'flexible'], ideal: 'REST: fixed endpoints, may over/under-fetch. GraphQL: single endpoint, fetch exactly what you need.' },
      { q: 'Explain the MVC architecture pattern.', keywords: ['model', 'view', 'controller', 'separation', 'concern', 'pattern', 'request'], ideal: 'Model: data/business logic. View: UI. Controller: handles requests, connects Model and View.' },
      { q: 'What is JWT? How does authentication work with JWT?', keywords: ['jwt', 'token', 'header', 'payload', 'signature', 'auth', 'stateless', 'bearer'], ideal: 'JWT = JSON Web Token. Server creates token on login, client sends in header, server validates.' },
      { q: 'What is the difference between SQL and NoSQL?', keywords: ['sql', 'nosql', 'relational', 'schema', 'document', 'scale', 'acid', 'flexible'], ideal: 'SQL: structured, relational, ACID. NoSQL: flexible schema, horizontal scaling, document/key-value.' },
      { q: 'Explain CORS and how to handle it.', keywords: ['cors', 'cross origin', 'browser', 'header', 'policy', 'allow', 'origin', 'preflight'], ideal: 'CORS prevents cross-origin requests. Add Access-Control-Allow-Origin header on server to allow.' },
      { q: 'What is Docker? Why is it useful?', keywords: ['docker', 'container', 'image', 'environment', 'deploy', 'consistent', 'isolated'], ideal: 'Docker packages app with dependencies in containers. Same environment everywhere. Solves "works on my machine".' },
      { q: 'How does HTTP work? What are status codes?', keywords: ['http', 'request', 'response', '200', '400', '401', '404', '500', 'status'], ideal: '200 OK, 400 Bad Request, 401 Unauthorized, 404 Not Found, 500 Server Error.' },
      { q: 'What is CI/CD?', keywords: ['continuous', 'integration', 'delivery', 'deploy', 'pipeline', 'automate', 'test', 'build'], ideal: 'CI: auto build/test on commit. CD: auto deploy to production. Reduces manual errors, faster releases.' },
      { q: 'Explain database indexing.', keywords: ['index', 'performance', 'query', 'search', 'slow', 'fast', 'btree', 'column'], ideal: 'Index is like a book index. Speeds up SELECT queries. Create on frequently queried columns.' },
      { q: 'Monolithic vs Microservices architecture?', keywords: ['monolithic', 'microservices', 'service', 'deploy', 'scale', 'independent', 'communicate'], ideal: 'Monolithic: single deployable unit. Microservices: independent services. Microservices scale better but complex.' },
    ],
    hr: [
      { q: 'Tell me about yourself.', keywords: ['fullstack', 'frontend', 'backend', 'project', 'skills', 'experience'], ideal: 'Mention both frontend and backend skills, projects.' },
      { q: 'Why full stack development?', keywords: ['both', 'frontend', 'backend', 'complete', 'versatile', 'end to end'], ideal: 'Ability to build complete products, versatility, end-to-end understanding.' },
      { q: 'What are your strengths and weaknesses?', keywords: ['strength', 'weakness', 'improve', 'skill'], ideal: 'Genuine answer with examples.' },
      { q: 'Describe your most challenging project.', keywords: ['project', 'challenge', 'solved', 'learned', 'built', 'feature'], ideal: 'Explain complexity, challenges overcome, tech used.' },
      { q: 'How do you manage both frontend and backend?', keywords: ['organize', 'plan', 'separate', 'api', 'communicate', 'structure'], ideal: 'Separate concerns, clear API contracts, good project structure.' },
      { q: 'How do you handle disagreements with teammates?', keywords: ['communicate', 'listen', 'discuss', 'agree', 'team', 'solution'], ideal: 'Listen first, discuss calmly, focus on best solution for project.' },
      { q: 'Tell me about a time you learned a new technology quickly.', keywords: ['learn', 'quickly', 'documentation', 'practice', 'project', 'adapt'], ideal: 'Give specific example with timeline and how you approached learning.' },
      { q: 'What is your preferred tech stack and why?', keywords: ['stack', 'react', 'node', 'net', 'database', 'why', 'comfortable'], ideal: 'Mention specific stack with reasoning — performance, community, familiarity.' },
      { q: 'How do you ensure code quality?', keywords: ['review', 'test', 'clean', 'solid', 'naming', 'comment', 'refactor'], ideal: 'Code reviews, unit tests, clean code principles, meaningful naming.' },
      { q: 'Do you have any questions for us?', keywords: ['team', 'stack', 'project', 'growth', 'culture'], ideal: 'Ask about team, tech stack, growth path.' },
    ],
  },
  qa: {
    technical: [
      { q: 'What is the difference between manual and automation testing?', keywords: ['manual', 'automation', 'selenium', 'human', 'script', 'repetitive', 'regression'], ideal: 'Manual: human executes tests. Automation: scripts execute tests. Automation best for repetitive/regression tests.' },
      { q: 'Explain the Software Testing Life Cycle (STLC).', keywords: ['requirement', 'planning', 'analysis', 'design', 'execution', 'closure', 'cycle'], ideal: 'Requirement Analysis → Test Planning → Test Design → Environment Setup → Execution → Closure.' },
      { q: 'What is regression testing?', keywords: ['regression', 'existing', 'new', 'change', 'break', 'feature', 'previous'], ideal: 'Testing existing features after new changes to ensure nothing is broken.' },
      { q: 'What is Selenium? How does it work?', keywords: ['selenium', 'browser', 'automate', 'webdriver', 'locator', 'script', 'element'], ideal: 'Selenium automates browser actions. WebDriver controls browser. Find elements using locators, perform actions.' },
      { q: 'What is smoke testing vs sanity testing?', keywords: ['smoke', 'sanity', 'build', 'stable', 'narrow', 'deep', 'basic'], ideal: 'Smoke: broad test of basic functionality after build. Sanity: narrow deep test of specific functionality.' },
      { q: 'Write a test case for login functionality.', keywords: ['test case', 'valid', 'invalid', 'empty', 'password', 'username', 'expected', 'actual'], ideal: 'Valid credentials, invalid password, empty fields, SQL injection, max length, forgot password.' },
      { q: 'What is bug life cycle?', keywords: ['new', 'assigned', 'open', 'fixed', 'retest', 'closed', 'reopen', 'rejected'], ideal: 'New → Assigned → Open → Fixed → Retest → Closed/Reopen.' },
      { q: 'What is API testing? Which tools?', keywords: ['api', 'postman', 'request', 'response', 'status', 'endpoint', 'rest', 'json'], ideal: 'Testing API endpoints for functionality, reliability, performance. Tools: Postman, RestAssured.' },
      { q: 'Black box vs white box testing?', keywords: ['black box', 'white box', 'internal', 'code', 'functionality', 'knowledge', 'structure'], ideal: 'Black box: test without knowing code. White box: test with code knowledge.' },
      { q: 'What is JIRA? How do you use it?', keywords: ['jira', 'bug', 'ticket', 'sprint', 'track', 'assign', 'status', 'agile'], ideal: 'JIRA is project management tool. Create bug tickets with steps, severity, priority, screenshots.' },
    ],
    hr: [
      { q: 'Tell me about yourself.', keywords: ['qa', 'testing', 'skills', 'project', 'experience', 'manual', 'automation'], ideal: 'Mention QA background, testing types known, tools used.' },
      { q: 'Why QA testing as a career?', keywords: ['quality', 'detail', 'find', 'bug', 'improve', 'software', 'user'], ideal: 'Passion for quality, attention to detail, improving user experience.' },
      { q: 'What are your strengths and weaknesses?', keywords: ['strength', 'weakness', 'detail', 'improve', 'analytical'], ideal: 'Attention to detail as strength. Mention weakness + improvement.' },
      { q: 'Tell me about a critical bug you found.', keywords: ['bug', 'found', 'impact', 'reported', 'fixed', 'severity', 'critical'], ideal: 'Describe bug, severity, how you found it, impact if not caught.' },
      { q: 'How do you prioritize test cases?', keywords: ['priority', 'critical', 'risk', 'impact', 'time', 'regression', 'smoke'], ideal: 'Risk-based approach: critical paths first, regression tests, then lower priority.' },
      { q: 'How do you handle pressure during releases?', keywords: ['calm', 'prioritize', 'communicate', 'plan', 'team', 'deadline', 'focus'], ideal: 'Stay calm, prioritize critical tests, communicate with team, focus on risk areas.' },
      { q: 'Describe your Agile team experience.', keywords: ['agile', 'sprint', 'standup', 'backlog', 'team', 'scrum', 'iteration'], ideal: 'Mention participation in sprints, standups, writing test cases from user stories.' },
      { q: 'How do you ensure thorough test coverage?', keywords: ['coverage', 'requirement', 'scenario', 'edge case', 'boundary', 'matrix', 'all'], ideal: 'Requirements traceability matrix, boundary value analysis, equivalence partitioning.' },
      { q: 'Have you disagreed with a developer about a bug?', keywords: ['disagree', 'evidence', 'reproduce', 'discuss', 'escalate', 'professional'], ideal: 'Stay professional, provide evidence (steps to reproduce, screenshots), escalate if needed.' },
      { q: 'Do you have any questions for us?', keywords: ['team', 'automation', 'tools', 'project', 'growth', 'stack'], ideal: 'Ask about automation framework, team structure, release cycle.' },
    ],
  },
}

const roles = [
  { value: 'dotnet', label: '⚙️ .NET Developer' },
  { value: 'frontend', label: '🎨 Frontend Developer' },
  { value: 'fullstack', label: '🚀 Full Stack Developer' },
  { value: 'qa', label: '🧪 QA Tester' },
]

const types = [
  { value: 'technical', label: '💻 Technical', color: '#38bdf8' },
  { value: 'hr', label: '🤝 HR Round', color: '#818cf8' },
  { value: 'mixed', label: '🎯 Mixed', color: '#34d399' },
]

function validateAnswer(answer, keywords) {
  if (!answer.trim()) return { score: 0, matched: [], missed: keywords }
  const lower = answer.toLowerCase()
  const matched = keywords.filter(k => lower.includes(k.toLowerCase()))
  const missed = keywords.filter(k => !lower.includes(k.toLowerCase()))
  const score = Math.round((matched.length / keywords.length) * 10)
  return { score, matched, missed }
}

function InterviewPractice() {
  const [screen, setScreen] = useState('setup')
  const [selectedRole, setSelectedRole] = useState('dotnet')
  const [selectedType, setSelectedType] = useState('technical')
  const [questions, setQuestions] = useState([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState([])
  const [currentAnswer, setCurrentAnswer] = useState('')
  const [timeLeft, setTimeLeft] = useState(120)
  const [isListening, setIsListening] = useState(false)
  const [showIdeal, setShowIdeal] = useState(false)
  const timerRef = useRef(null)
  const recognitionRef = useRef(null)

  const startPractice = () => {
    let qs = []
    const bank = questionBank[selectedRole]

    if (selectedType === 'mixed') {
      const tech = [...bank.technical].sort(() => Math.random() - 0.5).slice(0, 5)
      const hr = [...bank.hr].sort(() => Math.random() - 0.5).slice(0, 5)
      qs = [...tech, ...hr].sort(() => Math.random() - 0.5)
    } else {
      qs = [...bank[selectedType]].sort(() => Math.random() - 0.5)
    }

    setQuestions(qs)
    setCurrentIndex(0)
    setAnswers([])
    setCurrentAnswer('')
    setTimeLeft(120)
    setShowIdeal(false)
    setScreen('practice')
  }

  useEffect(() => {
    if (screen !== 'practice') return
    clearInterval(timerRef.current)
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current)
          handleNext(true)
          return 120
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(timerRef.current)
  }, [screen, currentIndex])

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      alert('Speech recognition not supported in this browser. Use Chrome.')
      return
    }

    const recognition = new SpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = 'en-IN'

    recognition.onresult = (event) => {
      let transcript = ''
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript
      }
      setCurrentAnswer(transcript)
    }

    recognition.onerror = () => {
      setIsListening(false)
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognitionRef.current = recognition
    recognition.start()
    setIsListening(true)
  }

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
    setIsListening(false)
  }

  const handleNext = (autoSkip = false) => {
    clearInterval(timerRef.current)
    if (recognitionRef.current) recognitionRef.current.stop()
    setIsListening(false)

    const validation = validateAnswer(
      currentAnswer,
      questions[currentIndex]?.keywords || []
    )

    const newAnswers = [...answers, {
      question: questions[currentIndex]?.q,
      answer: currentAnswer,
      skipped: autoSkip || !currentAnswer.trim(),
      timeUsed: 120 - timeLeft,
      validation,
      ideal: questions[currentIndex]?.ideal,
      keywords: questions[currentIndex]?.keywords,
    }]

    setAnswers(newAnswers)
    setCurrentAnswer('')
    setTimeLeft(120)
    setShowIdeal(false)

    if (currentIndex + 1 >= questions.length) {
      setScreen('result')
    } else {
      setCurrentIndex(prev => prev + 1)
    }
  }

  const formatTime = (sec) => {
    const m = Math.floor(sec / 60).toString().padStart(2, '0')
    const s = (sec % 60).toString().padStart(2, '0')
    return `${m}:${s}`
  }

  const timerColor = timeLeft > 60 ? '#34d399' : timeLeft > 30 ? '#f59e0b' : '#fb7185'
  const typeData = types.find(t => t.value === selectedType)
  const answered = answers.filter(a => !a.skipped).length
  const avgScore = answers.length > 0
    ? Math.round(answers.reduce((sum, a) => sum + (a.validation?.score || 0), 0) / answers.length)
    : 0

  // SETUP SCREEN
  if (screen === 'setup') {
    return (
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '60px 32px' }}>
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '8px',
            padding: '6px 16px', backgroundColor: 'rgba(56,189,248,0.1)',
            border: '1px solid rgba(56,189,248,0.3)', borderRadius: '100px',
            fontSize: '13px', color: '#38bdf8', fontWeight: '500', marginBottom: '16px',
            boxShadow: '0 0 20px rgba(56,189,248,0.1)',
          }}>
            ✦ Mock Interview
          </div>
          <h2 style={{
            fontSize: '40px', fontWeight: '800',
            background: 'var(--gradient)', WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent', marginBottom: '12px', letterSpacing: '-1px',
          }}>
            Interview Practice
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '16px', lineHeight: '1.7' }}>
            Practice real interview questions with timer + AI keyword validation + audio input
          </p>
        </div>

        {/* Role */}
        <div style={{
          padding: '32px', backgroundColor: 'rgba(255,255,255,0.02)',
          border: '1px solid rgba(56,189,248,0.2)', borderRadius: '20px',
          marginBottom: '20px', backdropFilter: 'blur(20px)',
          boxShadow: '0 0 40px rgba(56,189,248,0.05)',
        }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: '700', letterSpacing: '1px', marginBottom: '16px' }}>
            SELECT YOUR ROLE
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            {roles.map((role) => (
              <div key={role.value} onClick={() => setSelectedRole(role.value)} style={{
                padding: '16px 20px',
                backgroundColor: selectedRole === role.value ? 'rgba(56,189,248,0.1)' : 'rgba(255,255,255,0.03)',
                border: selectedRole === role.value ? '1px solid rgba(56,189,248,0.5)' : '1px solid rgba(255,255,255,0.08)',
                borderRadius: '12px', cursor: 'pointer', fontSize: '15px',
                fontWeight: selectedRole === role.value ? '700' : '500',
                color: selectedRole === role.value ? '#38bdf8' : 'var(--text-primary)',
                transition: 'all 0.2s ease', textAlign: 'center',
                boxShadow: selectedRole === role.value ? '0 0 20px rgba(56,189,248,0.15)' : 'none',
              }}>
                {role.label}
              </div>
            ))}
          </div>
        </div>

        {/* Type */}
        <div style={{
          padding: '32px', backgroundColor: 'rgba(255,255,255,0.02)',
          border: '1px solid rgba(56,189,248,0.2)', borderRadius: '20px',
          marginBottom: '32px', backdropFilter: 'blur(20px)',
          boxShadow: '0 0 40px rgba(56,189,248,0.05)',
        }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: '700', letterSpacing: '1px', marginBottom: '16px' }}>
            SELECT INTERVIEW TYPE
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
            {types.map((type) => (
              <div key={type.value} onClick={() => setSelectedType(type.value)} style={{
                padding: '20px',
                backgroundColor: selectedType === type.value ? `${type.color}12` : 'rgba(255,255,255,0.03)',
                border: selectedType === type.value ? `1px solid ${type.color}50` : '1px solid rgba(255,255,255,0.08)',
                borderRadius: '12px', cursor: 'pointer', textAlign: 'center',
                transition: 'all 0.2s ease',
                boxShadow: selectedType === type.value ? `0 0 20px ${type.color}15` : 'none',
              }}>
                <div style={{ fontSize: '28px', marginBottom: '8px' }}>{type.label.split(' ')[0]}</div>
                <p style={{ fontSize: '14px', fontWeight: '700', color: selectedType === type.value ? type.color : 'var(--text-primary)' }}>
                  {type.label.split(' ').slice(1).join(' ')}
                </p>
                <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  {type.value === 'technical' && '10 technical questions'}
                  {type.value === 'hr' && '10 HR questions'}
                  {type.value === 'mixed' && '5 tech + 5 HR'}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div style={{ textAlign: 'center' }}>
          <button onClick={startPractice} className="btn-primary" style={{
            padding: '16px 56px', fontSize: '18px', fontWeight: '700',
            borderRadius: '14px', letterSpacing: '0.3px',
          }}>
            🎯 Start Practice Session
          </button>
          <p style={{ marginTop: '12px', color: 'var(--text-secondary)', fontSize: '13px' }}>
            2 min per question · Randomized · Audio input supported · Keyword validation
          </p>
        </div>
      </div>
    )
  }

  // PRACTICE SCREEN
  if (screen === 'practice') {
    const progress = (currentIndex / questions.length) * 100
    const currentQ = questions[currentIndex]

    return (
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '60px 32px' }}>

        {/* Progress */}
        <div style={{ marginBottom: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ color: 'var(--text-secondary)', fontSize: '13px', fontWeight: '600' }}>
              Question {currentIndex + 1} of {questions.length}
            </span>
            <span style={{ color: typeData?.color, fontSize: '13px', fontWeight: '600' }}>
              {roles.find(r => r.value === selectedRole)?.label}
            </span>
          </div>
          <div style={{ height: '6px', backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: '100px', overflow: 'hidden' }}>
            <div style={{
              height: '100%', width: `${progress}%`,
              background: 'var(--gradient)', borderRadius: '100px',
              transition: 'width 0.5s ease',
            }} />
          </div>
        </div>

        {/* Timer */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '10px',
            padding: '12px 28px', backgroundColor: `${timerColor}12`,
            border: `1px solid ${timerColor}40`, borderRadius: '100px',
            boxShadow: `0 0 20px ${timerColor}20`,
          }}>
            <div style={{
              width: '8px', height: '8px', borderRadius: '50%',
              backgroundColor: timerColor, animation: 'pulse 1s ease-in-out infinite',
            }} />
            <span style={{ fontSize: '22px', fontWeight: '800', color: timerColor, fontFamily: 'monospace' }}>
              {formatTime(timeLeft)}
            </span>
          </div>
        </div>

        {/* Question */}
        <div key={currentIndex} className="fade-in" style={{
          padding: '36px', backgroundColor: 'rgba(255,255,255,0.02)',
          border: `1px solid ${typeData?.color}30`, borderRadius: '20px',
          marginBottom: '20px', backdropFilter: 'blur(20px)',
          boxShadow: `0 0 40px ${typeData?.color}08`, position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: '-30px', right: '-30px', width: '150px', height: '150px', borderRadius: '50%', background: `radial-gradient(circle, ${typeData?.color}15, transparent)`, pointerEvents: 'none' }} />

          <span style={{
            padding: '4px 12px', backgroundColor: `${typeData?.color}15`,
            border: `1px solid ${typeData?.color}40`, borderRadius: '100px',
            fontSize: '12px', color: typeData?.color, fontWeight: '700',
            display: 'inline-block', marginBottom: '16px',
          }}>
            {selectedType === 'hr' ? '🤝 HR' : '💻 Technical'}
          </span>

          <p style={{ fontSize: '20px', fontWeight: '600', color: 'var(--text-primary)', lineHeight: '1.6' }}>
            {currentQ?.q}
          </p>

          {/* Keywords hint */}
          <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <p style={{ fontSize: '11px', color: 'var(--text-secondary)', marginBottom: '8px', fontWeight: '600', letterSpacing: '0.5px' }}>
              KEY POINTS TO COVER:
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {currentQ?.keywords?.slice(0, 5).map((kw, i) => (
                <span key={i} style={{
                  padding: '2px 8px', backgroundColor: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.08)', borderRadius: '100px',
                  fontSize: '11px', color: 'var(--text-secondary)',
                }}>
                  {kw}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Answer Box */}
        <div style={{ marginBottom: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <label style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: '700', letterSpacing: '1px' }}>
              YOUR ANSWER
            </label>
            {/* Audio Button */}
            <button
              onClick={isListening ? stopListening : startListening}
              style={{
                padding: '8px 16px',
                background: isListening
                  ? 'linear-gradient(135deg, rgba(251,113,133,0.2), rgba(251,113,133,0.05))'
                  : 'linear-gradient(135deg, rgba(52,211,153,0.15), rgba(52,211,153,0.05))',
                border: isListening ? '1px solid rgba(251,113,133,0.5)' : '1px solid rgba(52,211,153,0.4)',
                borderRadius: '10px',
                color: isListening ? '#fb7185' : '#34d399',
                fontSize: '13px',
                fontWeight: '700',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                transition: 'all 0.2s ease',
                boxShadow: isListening ? '0 0 20px rgba(251,113,133,0.2)' : '0 0 15px rgba(52,211,153,0.1)',
              }}
            >
              {isListening ? (
                <>
                  <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#fb7185', display: 'inline-block', animation: 'pulse 1s infinite' }} />
                  Stop Recording
                </>
              ) : (
                <>🎤 Speak Answer</>
              )}
            </button>
          </div>

          <textarea
            value={currentAnswer}
            onChange={e => setCurrentAnswer(e.target.value)}
            placeholder={isListening ? '🎤 Listening... speak your answer...' : 'Type your answer or click 🎤 to speak...'}
            style={{
              width: '100%', height: '160px', padding: '16px',
              backgroundColor: isListening ? 'rgba(52,211,153,0.03)' : 'rgba(255,255,255,0.03)',
              color: 'var(--text-primary)',
              border: isListening ? '1px solid rgba(52,211,153,0.4)' : `1px solid ${typeData?.color}25`,
              borderRadius: '14px', fontSize: '15px', resize: 'none', outline: 'none',
              fontFamily: 'Inter, sans-serif', lineHeight: '1.7', boxSizing: 'border-box',
              transition: 'all 0.2s ease',
              boxShadow: isListening ? '0 0 0 3px rgba(52,211,153,0.08)' : 'none',
            }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '6px' }}>
            <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
              {currentAnswer.length} characters
            </span>
            {currentAnswer && (
              <button onClick={() => setCurrentAnswer('')} style={{
                background: 'none', border: 'none', color: '#94a3b8',
                fontSize: '12px', cursor: 'pointer',
              }}>
                ✕ Clear
              </button>
            )}
          </div>
        </div>

        {/* Show Ideal Answer */}
        {showIdeal && (
          <div className="fade-in" style={{
            padding: '16px 20px',
            backgroundColor: 'rgba(129,140,248,0.05)',
            border: '1px solid rgba(129,140,248,0.2)',
            borderRadius: '12px',
            marginBottom: '16px',
          }}>
            <p style={{ fontSize: '12px', color: '#818cf8', fontWeight: '700', marginBottom: '6px' }}>
              💡 IDEAL ANSWER HINT:
            </p>
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: '1.6' }}>
              {currentQ?.ideal}
            </p>
          </div>
        )}

        {/* Buttons */}
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap' }}>
          <button
            onClick={() => setShowIdeal(!showIdeal)}
            style={{
              padding: '12px 20px', backgroundColor: 'transparent',
              color: '#818cf8', border: '1px solid rgba(129,140,248,0.3)',
              borderRadius: '12px', fontSize: '14px', fontWeight: '600', cursor: 'pointer',
            }}
          >
            💡 {showIdeal ? 'Hide' : 'Show'} Hint
          </button>
          <button
            onClick={() => handleNext(true)}
            style={{
              padding: '12px 24px', backgroundColor: 'transparent',
              color: '#94a3b8', border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '12px', fontSize: '14px', fontWeight: '600', cursor: 'pointer',
            }}
          >
            ⏭ Skip
          </button>
          <button onClick={() => handleNext(false)} className="btn-primary" style={{
            padding: '12px 40px', fontSize: '15px', fontWeight: '700', borderRadius: '12px',
          }}>
            {currentIndex + 1 >= questions.length ? '🏁 Finish' : 'Next →'}
          </button>
        </div>
      </div>
    )
  }

  // RESULT SCREEN
  if (screen === 'result') {
    const percentage = Math.round((answered / questions.length) * 100)

    return (
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '60px 32px' }}>

        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <div style={{ fontSize: '56px', marginBottom: '16px' }}>
            {percentage >= 70 ? '🏆' : percentage >= 50 ? '👍' : '💪'}
          </div>
          <h2 style={{
            fontSize: '36px', fontWeight: '800',
            background: 'var(--gradient)', WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent', marginBottom: '8px',
          }}>
            Session Complete!
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '16px' }}>
            {percentage >= 70 ? 'Excellent! You are interview ready! 🚀' : percentage >= 50 ? 'Good effort! Keep practicing.' : 'Keep going — practice makes perfect!'}
          </p>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '16px', marginBottom: '32px' }}>
          {[
            { label: 'Answered', value: answered, color: '#34d399' },
            { label: 'Skipped', value: questions.length - answered, color: '#fb7185' },
            { label: 'Completion', value: `${percentage}%`, color: '#38bdf8' },
            { label: 'Avg Score', value: `${avgScore}/10`, color: '#818cf8' },
          ].map((stat) => (
            <div key={stat.label} style={{
              padding: '24px', backgroundColor: 'rgba(255,255,255,0.03)',
              border: `1px solid ${stat.color}25`, borderRadius: '16px',
              textAlign: 'center', boxShadow: `0 0 20px ${stat.color}08`,
            }}>
              <div style={{ fontSize: '28px', fontWeight: '800', color: stat.color, marginBottom: '6px' }}>
                {stat.value}
              </div>
              <div style={{ fontSize: '13px', color: 'var(--text-secondary)', fontWeight: '600' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Questions Review */}
        <div style={{
          padding: '32px', backgroundColor: 'rgba(255,255,255,0.02)',
          border: '1px solid rgba(56,189,248,0.15)', borderRadius: '20px', marginBottom: '32px',
        }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: '700', letterSpacing: '1px', marginBottom: '20px' }}>
            📋 DETAILED REVIEW
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {answers.map((item, i) => (
              <div key={i} style={{
                padding: '20px',
                backgroundColor: item.skipped ? 'rgba(251,113,133,0.04)' : 'rgba(52,211,153,0.04)',
                border: item.skipped ? '1px solid rgba(251,113,133,0.2)' : '1px solid rgba(52,211,153,0.15)',
                borderRadius: '14px',
              }}>
                {/* Question */}
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px', gap: '12px' }}>
                  <p style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-primary)', flex: 1 }}>
                    Q{i + 1}: {item.question}
                  </p>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center', minWidth: 'fit-content' }}>
                    {!item.skipped && (
                      <span style={{
                        padding: '3px 10px',
                        backgroundColor: item.validation.score >= 7 ? 'rgba(52,211,153,0.15)' : item.validation.score >= 4 ? 'rgba(245,158,11,0.15)' : 'rgba(251,113,133,0.15)',
                        border: `1px solid ${item.validation.score >= 7 ? 'rgba(52,211,153,0.4)' : item.validation.score >= 4 ? 'rgba(245,158,11,0.4)' : 'rgba(251,113,133,0.4)'}`,
                        borderRadius: '100px',
                        fontSize: '12px',
                        color: item.validation.score >= 7 ? '#34d399' : item.validation.score >= 4 ? '#f59e0b' : '#fb7185',
                        fontWeight: '700',
                      }}>
                        {item.validation.score}/10
                      </span>
                    )}
                    <span style={{
                      fontSize: '12px',
                      color: item.skipped ? '#fb7185' : '#34d399',
                      fontWeight: '700',
                    }}>
                      {item.skipped ? '⏭ Skipped' : '✓ Answered'}
                    </span>
                  </div>
                </div>

                {/* Answer */}
                {!item.skipped && item.answer && (
                  <div style={{
                    padding: '10px 14px',
                    backgroundColor: 'rgba(255,255,255,0.03)',
                    borderRadius: '8px',
                    marginBottom: '10px',
                  }}>
                    <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: '1.6' }}>
                      📝 {item.answer}
                    </p>
                  </div>
                )}

                {/* Keyword Validation */}
                {!item.skipped && (
                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '10px' }}>
                    {item.validation.matched.length > 0 && (
                      <div>
                        <p style={{ fontSize: '11px', color: '#34d399', fontWeight: '700', marginBottom: '4px' }}>✓ COVERED:</p>
                        <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                          {item.validation.matched.map((kw, j) => (
                            <span key={j} style={{
                              padding: '2px 8px', backgroundColor: 'rgba(52,211,153,0.1)',
                              border: '1px solid rgba(52,211,153,0.3)', borderRadius: '100px',
                              fontSize: '11px', color: '#34d399',
                            }}>
                              {kw}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    {item.validation.missed.length > 0 && (
                      <div>
                        <p style={{ fontSize: '11px', color: '#fb7185', fontWeight: '700', marginBottom: '4px' }}>✗ MISSED:</p>
                        <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                          {item.validation.missed.map((kw, j) => (
                            <span key={j} style={{
                              padding: '2px 8px', backgroundColor: 'rgba(251,113,133,0.1)',
                              border: '1px solid rgba(251,113,133,0.3)', borderRadius: '100px',
                              fontSize: '11px', color: '#fb7185',
                            }}>
                              {kw}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Ideal Answer */}
                <div style={{
                  padding: '10px 14px',
                  backgroundColor: 'rgba(129,140,248,0.05)',
                  border: '1px solid rgba(129,140,248,0.15)',
                  borderRadius: '8px',
                }}>
                  <p style={{ fontSize: '11px', color: '#818cf8', fontWeight: '700', marginBottom: '4px' }}>
                    💡 IDEAL ANSWER:
                  </p>
                  <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: '1.6' }}>
                    {item.ideal}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Buttons */}
        <div style={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
          <button onClick={() => setScreen('setup')} style={{
            padding: '14px 32px', backgroundColor: 'transparent',
            color: '#38bdf8', border: '1px solid rgba(56,189,248,0.4)',
            borderRadius: '12px', fontSize: '15px', fontWeight: '600', cursor: 'pointer',
          }}>
            ← Back to Setup
          </button>
          <button onClick={startPractice} className="btn-primary" style={{
            padding: '14px 32px', fontSize: '15px', fontWeight: '700', borderRadius: '12px',
          }}>
            🔄 Practice Again
          </button>
        </div>
      </div>
    )
  }
}

export default InterviewPractice